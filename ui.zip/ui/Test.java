package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.bean.AccountHoldingType;
import com.cg.ibs.investment.bean.AccountStatus;
import com.cg.ibs.investment.bean.AccountType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.Gender;
import com.cg.ibs.investment.bean.GoldPrice;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MFType;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.SilverPrice;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.service.AdditionService;
import com.cg.ibs.investment.service.CSIMPL;
import com.cg.ibs.investment.service.FetchService;
import com.cg.ibs.investment.util.JPAUtil;

public class Test {

	public static void main(String[] args) {
		System.out.println("Enter the date you want to start the investment in the format DD/MM/YYYY");
		DateTimeFormatter format= DateTimeFormatter.ofPattern("d/MM/yyyy");
        Scanner sc= new Scanner(System.in);
		String date= null;
		boolean check1=true;
		boolean check2= true;
	    while(check1) {
	    	 date= sc.next();
	    	 while(check2) {
	    		 System.out.println(date.matches("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$"));
	    		 if(date.matches("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$")) {
	    			check2=false; 
	    		 }
	    		 else {
	    		 System.out.println("Enter the date again");
	    		 date=sc.next();}
	    	 }
	      
	    	 
	    	 
	    	 
			String arr[]=date.split("[/]");
			int days= Integer.parseInt(arr[0]);
			int month= Integer.parseInt(arr[1]);
			int year=Integer.parseInt(arr[2]);
			System.out.println(days);
			System.out.println(month);
			System.out.println(year);
	     
		if(isValidDate(days, month, year)) {
			check1=false;					
			
		}
		else {
		System.out.println("Please enter valid date");
		date= sc.next();}
		
	    }
		LocalDate buydate=LocalDate.parse(date, format);
	
		
	    
		System.out.println("liihow");	
	}
	static boolean isLeap(int year) 
    { 
        // Return true if year is  
        // a multiple of 4 and not  
        // multiple of 100. 
        // OR year is multiple of 400. 
        return (year % 4 == 0) ; 
    }
	
	 static boolean isValidDate(int d, int m, int y) 
	    { 
	        // If year, month and day  
	        // are not in given range 
	         
	        if (m < 1 || m > 12) 
	            return false; 
	        if (d < 1 || d > 31) 
	            return false; 
	  
	        // Handle February month 
	        // with leap year 
	        if (m == 2)  
	        { 
	            if (isLeap(y)) 
	                return (d <= 29); 
	            else
	                return (d <= 28); 
	        } 
	  
	        // Months of April, June,  
	        // Sept and Nov must have  
	        // number of days less than 
	        // or equal to 30. 
	        if (m == 4 || m == 6 ||  
	            m == 9 || m == 11) 
	            return (d <= 30); 
	  
	        return true; 
	    } 

		
		
	

	
}
