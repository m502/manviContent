package com.cg.ibs.investment.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;
@Component
public class BankUI {
	static Scanner sc=new Scanner(System.in);
	//static int status = 3;
	static Logger log = Logger.getLogger(InvestmentUI.class.getName());
//	ApplicationContext context=new ClassPathXmlApplicationContext("investment.xml");

	// Declaring objects of Client Service and Bank Service
	/*CustomerService service = new CustomerServiceImpl();
	BankService bankservice = new BankServiceImpl();*/
	@Autowired
	CustomerService service;
	@Autowired
	BankService bankservice;

	public void updateMf() {
		System.out.println("1. Update NAV");
		System.out.println("2. Update Minimum Direct Amount");
		System.out.println("3. Update Minimum SIP Amount");
		System.out.println("4. Update SIP Status");
		System.out.println("5. Update Direct Investment Status");
		System.out.println("Enter the option number you want to choose: ");
		 boolean check1 = true;
		 String tempUpdate = sc.next();
			int stat = 0;
			while (check1) {
				if (tempUpdate.matches("[1-5]")) {
					stat= Integer.parseInt(tempUpdate);
					
						check1 = false;
					
				} else {
					System.out.println("Please Re-enter the value");
					tempUpdate = sc.next();
				}

			}
			
		boolean check = true;
		try {
			if(stat==1) {
			String format = "%1$-20s%2$-20s%3$-20s\n";
			String string = "ID";
			String string2 = "Title";
			String string3 = "NAV(INR)";
			System.out.println("----------------------------------------------------");
			System.out.format(format, string, string2, string3);
			System.out.println("----------------------------------------------------");

			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {

				System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
						entry.getValue().getNav());
			}

			System.out.println("Enter the plan Id you want to choose");
			int mfPlanId = 0;
			String temp = sc.next();
			while (check) {
				if (temp.matches("[0-9]{1,10}")) {
					mfPlanId = Integer.parseInt(temp);

					if (service.viewMFPlans().containsKey(mfPlanId)) {

						check = false;
					} else {
						System.out.println("Please enter correct planId");
						temp = sc.next();
					}
				} else {
					System.out.println("Please enter valid planId");
					temp = sc.next();

				}
			}
			System.out.println("Enter nav value");
			String navTemp = sc.next();
			double nav = 0;
			boolean check11 = true;
			while (check11) {
				if (navTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
					nav = Double.parseDouble(navTemp);
					if (nav > 0) {
						check11 = false;
					} else {
						System.out.println("Please enter the valid NAV");
						navTemp = sc.next();
					}
				} else {
					System.out.println("Please Re-enter the value");
					navTemp = sc.next();
				}

			}
			bankservice.updateNav(mfPlanId, nav);
			System.out.println("NAV updated successfully");
		}
			
			
			
			
			else if(stat==2) {
				viewMFPlans("DIRECT");
				System.out.println("Enter the plan Id you want to choose");
				check=true;
				int mfPlanId = 0;
				String temp = sc.next();
				while (check) {
					if (temp.matches("[0-9]{1,10}")) {
						mfPlanId = Integer.parseInt(temp);

						if (service.viewMFPlans().containsKey(mfPlanId)) {

							check = false;
						} else {
							System.out.println("Please enter correct planId");
							temp = sc.next();
						}
					} else {
						System.out.println("Please enter valid planId");
						temp = sc.next();

					}
				}
				check1 = true;
			    System.out.println("Enter minimum amount for Direct Investments");
				String minDirTemp = sc.next();
				double minDir = 0;
				while (check1) {
					if (minDirTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
						minDir = Double.parseDouble(minDirTemp);
						if (minDir> 0) {
							check1 = false;
						} else {
							System.out.println("Please enter the valid amount");
							minDirTemp = sc.next();
						}
					} else {
						System.out.println("Please Re-enter the value");
						minDirTemp = sc.next();
					}

				}
				bankservice.updateMinDir(mfPlanId, minDir);
				System.out.println("Direct Investment Amount updated successfully");
			}
			else if(stat==3) {
				viewMFPlans("SIP");
				System.out.println("Enter the plan Id you want to choose");
				check=true;
				int mfPlanId = 0;
				String temp = sc.next();
				while (check) {
					if (temp.matches("[0-9]{1,10}")) {
						mfPlanId = Integer.parseInt(temp);

						if (service.viewMFPlans().containsKey(mfPlanId)) {

							check = false;
						} else {
							System.out.println("Please enter correct planId");
							temp = sc.next();
						}
					} else {
						System.out.println("Please enter valid planId");
						temp = sc.next();

					}
				}
		
				check1 = true;
			    System.out.println("Enter minimum amount for SIP Investments");
				String minSIPTemp = sc.next();
				double minSIP = 0;
				while (check1) {
					if (minSIPTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
						minSIP = Double.parseDouble(minSIPTemp);
						if (minSIP> 0) {
							check1 = false;
						} else {
							System.out.println("Please enter the valid amount");
							minSIPTemp = sc.next();
						}
					} else {
						System.out.println("Please Re-enter the value");
						minSIPTemp = sc.next();
					}

				}
				bankservice.updateNav(mfPlanId, minSIP);
				System.out.println("SIP minimum investment amount updated successfully");
			}
			else if(stat==4) {
				viewMFPlans("SIP_AND_DIRECT");
				System.out.println("Enter the plan Id you want to choose");
				check=true;
				int mfPlanId = 0;
				String temp = sc.next();
				while (check) {
					if (temp.matches("[0-9]{1,10}")) {
						mfPlanId = Integer.parseInt(temp);

						if (service.viewMFPlans().containsKey(mfPlanId)) {

							check = false;
						} else {
							System.out.println("Please enter correct planId");
							temp = sc.next();
						}
					} else {
						System.out.println("Please enter valid planId");
						temp = sc.next();

					}
				}
		
				System.out.println("Enter SIP Status:");
				System.out.println("1.ON");
				System.out.println("2.OFF");
				System.out.println("Please enter option number");
				 check1 = true;
				 String SIPstattemp = sc.next();
					int SIPstat = 0;
					while (check1) {
						if (SIPstattemp.matches("[1]")||SIPstattemp.matches("[2]")) {
							SIPstat= Integer.parseInt(SIPstattemp);
							
								check1 = false;
							
						} else {
							System.out.println("Please Re-enter the value");
							SIPstattemp = sc.next();
						}

					}
					if(SIPstat==1) {
				bankservice.updateSipStatus(mfPlanId, true);}
					else if(SIPstat==2) {
						bankservice.updateSipStatus(mfPlanId, false);
						
					}
				System.out.println("SIP status updated successfully");
			}
			else if(stat==5) {
				viewMFPlans("SIP_AND_DIRECT");
				System.out.println("Enter the plan Id you want to choose");
				check=true;
				int mfPlanId = 0;
				String temp = sc.next();
				while (check) {
					if (temp.matches("[0-9]{1,10}")) {
						mfPlanId = Integer.parseInt(temp);

						if (service.viewMFPlans().containsKey(mfPlanId)) {

							check = false;
						} else {
							System.out.println("Please enter correct planId");
							temp = sc.next();
						}
					} else {
						System.out.println("Please enter valid planId");
						temp = sc.next();

					}
				}
		
				System.out.println("Enter SIP Status:");
				System.out.println("1.ON");
				System.out.println("2.OFF");
				System.out.println("Please enter option number");
				 check1 = true;
				 String SIPstattemp = sc.next();
					int SIPstat = 0;
					while (check1) {
						if (SIPstattemp.matches("[1]")||SIPstattemp.matches("[2]")) {
							SIPstat= Integer.parseInt(SIPstattemp);
							
								check1 = false;
							
						} else {
							System.out.println("Please Re-enter the value");
							SIPstattemp = sc.next();
						}

					}
					if(SIPstat==1) {
						bankservice.updateDirStatus(mfPlanId, true);}
							else if(SIPstat==2) {
								bankservice.updateDirStatus(mfPlanId, false);
								
							}
					
				System.out.println("Status updated successfully");
			}
			
			log.info("user withdraws from mutual fund");
		} catch (IBSException exp) {
			log.error(exp);
			System.out.println(exp.getMessage());
		}

	}

	// Bank representative updates gold price
	public void updateGoldPrice() {
		boolean success = true;
		System.out.println("Enter the updated gold price");
		String goldPrice = sc.next();
		double GoldPrice = 0;
		try {
			while (success) {
				if (goldPrice.matches("[+]?[0-9]*\\.?[0-9]+")) {
					GoldPrice = Double.parseDouble(goldPrice);
					if (GoldPrice > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						goldPrice = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					goldPrice = sc.next();

				}
			}

			if (bankservice.updateGoldPrice(GoldPrice)) {
				System.out.println("Gold Price updated successfully");
			} else {
				System.out.println("Already updated");
			}
			log.info("Bank updates Gold Price");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Bank representative updates Silver price
	public void updateSiverPrice() {
		boolean success = true;
		System.out.println("Enter the updated silver price");
		String silverPrice = sc.next();
		double SilverPrice = 0;
		try {
			while (success) {
				if (silverPrice.matches("[+]?[0-9]*\\.?[0-9]+")) {
					SilverPrice = Double.parseDouble(silverPrice);
					if (SilverPrice > 0) {

						success = false;
					} else {
						System.out.println("Please  Re-enter the value");
						silverPrice = sc.next();
					}
				} else {

					System.out.println("Please  Re-enter the value");
					silverPrice = sc.next();

				}
			}

			if (bankservice.updateSilverPrice(SilverPrice)) {
				System.out.println("Silver Price updated successfully");
			} else {
				System.out.println("Already updated");
			}

			log.info("Bank updates silver price");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}
	}

	// Bank representative adds Mutual Fund plans
	public void addMFPlans() {
		boolean check = true;
		System.out.println("Enter mutualfundId");
		String temp = sc.next();
		int mfId = 0;
		while (check) {

			if (temp.matches("[1-9][0-9]{2,10}")) {

				mfId = Integer.parseInt(temp);
				try {
					if (service.viewMFPlans().containsKey(mfId) == false) {

						check = false;
					} else {
						System.out.println("MF Id already exists.");
						temp = sc.nextLine();

					}

				} catch (IBSException e) {
					log.error(e);
					System.out.println(e.getMessage());
				}

			}

			else {
				System.out.println("Please Re-enter the value");
				temp = sc.next();

			}

		}

	
		System.out.println("Enter mutualfundtitle");
		String title = sc.next();
		
		boolean check1 = true;
		System.out.println("Enter nav value");
		String navTemp = sc.next();
		double nav = 0;
		while (check1) {
			if (navTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
				nav = Double.parseDouble(navTemp);
				if (nav > 0) {
					check1 = false;
				} else {
					System.out.println("Please enter the valid NAV");
					navTemp = sc.next();
				}
			} else {
				System.out.println("Please Re-enter the value");
				navTemp = sc.next();
			}

		}
		
	    check1 = true;
	    System.out.println("Enter minimum amount for Direct Investments");
		String minDirTemp = sc.next();
		double minDir = 0;
		while (check1) {
			if (minDirTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
				minDir = Double.parseDouble(minDirTemp);
				if (minDir> 0) {
					check1 = false;
				} else {
					System.out.println("Please enter the valid amount");
					minDirTemp = sc.next();
				}
			} else {
				System.out.println("Please Re-enter the value");
				minDirTemp = sc.next();
			}

		}
		 check1 = true;
		    System.out.println("Enter minimum amount for SIP Investments");
			String minSIPTemp = sc.next();
			double minSIP = 0;
			while (check1) {
				if (minSIPTemp.matches("[+]?[0-9]*\\.?[0-9]+")) {
					minSIP = Double.parseDouble(minSIPTemp);
					if (minSIP> 0) {
						check1 = false;
					} else {
						System.out.println("Please enter the valid amount");
						minSIPTemp = sc.next();
					}
				} else {
					System.out.println("Please Re-enter the value");
					minSIPTemp = sc.next();
				}

			}
			
			System.out.println("Enter SIP Status:");
			System.out.println("1.ON");
			System.out.println("2.OFF");
			System.out.println("Please enter option number");
			 check1 = true;
			 String SIPstattemp = sc.next();
				int SIPstat = 0;
				while (check1) {
					if (SIPstattemp.matches("[1]")||SIPstattemp.matches("[2]")) {
						SIPstat= Integer.parseInt(SIPstattemp);
						
							check1 = false;
						
					} else {
						System.out.println("Please Re-enter the value");
						SIPstattemp = sc.next();
					}

				}

		try {
			BankMutualFund MF = new BankMutualFund();
			MF.setTitle(title);
			MF.setMfPlanId(mfId);
			MF.setNav(nav);
			MF.setMinAmtDir(minDir);
			MF.setMinAmtSip(minSIP);
			if(SIPstat==1) {
			MF.setSipStatus(true);}
			else if(SIPstat==2){
				MF.setSipStatus(false);
			}
		
           MF.setLaunchDate(LocalDate.now());
           MF.setDirStatus(true);
			bankservice.addMF(MF);
			System.out.println("Mutual Fund plans updated successfully");
			log.info("Bank adds Mutual Fund");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}
	public void viewMFPlans(String a) {
		try {
		
		String format = "%1$-20s%2$-20s%3$-20s%4$-20s%5$-20s\n";
		String string1 = "ID";
		String string2 = "Title";
		String string3="Type";
		String string4 = "NAV(INR)";
		String string5="LAUNCH DATE";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
		
		
		System.out.println("--------------------------------------------------------------------------");
		System.out.format(format, string1, string2, string3,string4,string5);
		System.out.println("--------------------------------------------------------------------------");
		if (a == "SIP") {
			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {
				if (entry.getValue().getSipStatus() == true ) {
					System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(), "SIP",
							entry.getValue().getNav(),formatter.format(entry.getValue().getLaunchDate()));
				}

			}
		} else if (a == "DIRECT") {
			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {
				if (entry.getValue().getDirStatus() == true) {
					System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(), "DIRECT",
							entry.getValue().getNav(),formatter.format(entry.getValue().getLaunchDate()));
				}

			}
		} else if (a == "SIP_AND_DIRECT") {
			for (Entry<Integer, BankMutualFund> entry : service.viewMFPlans().entrySet()) {
				
					System.out.format(format, entry.getValue().getMfPlanId(), entry.getValue().getTitle(),
						"SIP/DIRECT", entry.getValue().getNav(),formatter.format(entry.getValue().getLaunchDate()));
			
			}
		}
			log.info("User views Mutual fund offerd by bank");
		} catch (IBSException e) {
			log.error(e);
			System.out.println(e.getMessage());
		}

	}
	public void removeMf()  {
		
		viewMFPlans("SIP_AND_DIRECT");
		System.out.println("Enter the plan Id you want to choose");
		boolean check=true;
		int mfPlanId = 0;
		String temp = sc.next();
		while (check) {
			if (temp.matches("[0-9]{1,10}")) {
				mfPlanId = Integer.parseInt(temp);

				try {
					if (service.viewMFPlans().containsKey(mfPlanId)) {

						check = false;
					} else {
						System.out.println("Please enter correct planId");
						temp = sc.next();
					}
				} catch (IBSException e) {
					log.error(e);
					System.out.println(e.getMessage());
				}
			} else {
				System.out.println("Please enter valid planId");
				temp = sc.next();

			}
		}
		
		System.out.println("MfPlan Removed Successfully");
		
	}
}
