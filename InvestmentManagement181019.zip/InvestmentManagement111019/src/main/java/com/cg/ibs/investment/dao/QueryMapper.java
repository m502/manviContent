package com.cg.ibs.investment.dao;

public interface QueryMapper {
	public static final String VIEW_GOLD_PRICE = 
			"select update_date,gold_price from gold_price  where update_date=? order by update_date";
	public static final String UPDATE_GOLD_PRICE = "insert into gold_price values(?,?)";
	public static final String VIEW_MY_INVESTMENT = "select uci ,user_id,PASSWORD from customers where user_id=?";
	public static final String VIEW_MY_ASSETS = "select customers.uci , investment_bean.account_number,investment_bean.gold_units,investment_bean.silver_units from INVESTMENT_BEAN Inner join customers on investment_bean.uci=customers.uci where customers.uci=?";
	// public static final String VIEW_MY_MF="select mf_id ,mf_plan_id ,mf_units
	// ,mf_amount ,opening_date,closing_date from MUTUAL_FUND where uci number=?";
	public static final String VIEW_MY_Tranasactions = "select account_number ,  trans_id , trans_type , trans_date_time , amount ,   description from Transaction  where account_number=?";
	public static final String VIEW_MY_BALANCE = "select CURRENT_BALANCE from accounts where account_number=?";
	public static final String VIEW_BANK_MF = "select mutual_fund.mf_plan_id,bank_mutualmf_title,nav from bank_mutual_fund Inner join ";
	public static final String VIEW_MY_MF = "select mutual_fund.mf_id ,bank_mutual_fund.mf_plan_id,bank_mutual_fund.mf_title, bank_mutual_fund.nav,mutual_fund.mf_units ,mutual_fund.mf_amount ,mutual_fund.opening_date,mutual_fund.closing_date from MUTUAL_FUND  Inner JOIN Bank_mutual_fund on mutual_fund.mf_plan_id=bank_mutual_fund.mf_plan_id where mutual_fund.uci =?";
}
