package com.cg.ibs.investment.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.TreeSet;

import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.investment.bean.*;
import com.cg.ibs.investment.exception.IBSException;

public interface ClientDao {
	double viewGoldPrice() throws IBSException ;

	double viewSilverPrice();

	InvestmentBean viewInvestments(String userId) throws IBSException;

	HashMap<Integer, BankMutualFund> viewMF();

	public void updateTransaction(String uCI, int choice, InvestmentBean investmentBean, double amount);

	public void updateUnits(String userId, double gunits, InvestmentBean investmentBean, int choice);

	public void addMFInvestments(double mfAmount, int mfId, InvestmentBean investmentBean);

	public void withdrawMF(String userId, MutualFund mutualFund, InvestmentBean investmentBean);

	public TreeSet<TransactionBean> getTransactions(String userId);

}