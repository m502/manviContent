package com.cg.ibs.investment.service;

import com.cg.ibs.investment.dao.BankDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.exception.ErrorMessages;
import com.cg.ibs.investment.exception.InvalidDetailsException;
import com.cg.ibs.investment.exception.InvalidGoldPriceException;
import com.cg.ibs.investment.exception.InvalidMFException;
import com.cg.ibs.investment.exception.InvalidSilverPriceException;

public class BankServiceImpl implements BankService {
BankDao daoObject = new InvestmentDaoImpl();
	
	
	public boolean isValidGoldSilver(double price) {
		boolean check = false;
		if(price>0){
			check=true;
		}
		return check;
	}
	public boolean isValidMutualFund(BankMutualFund mutualFund){
		boolean check = false;
		if( mutualFund.getNav()>0){
			check=true;
		}
		return check;
	}
	public void updateGoldPrice(double goldPrice) throws InvalidGoldPriceException {			//Method to update Gold price
		if(isValidGoldSilver(goldPrice)){
			daoObject.updateGoldPrice(goldPrice);
		}
		else{
			throw new InvalidGoldPriceException(ErrorMessages.invalidPriceMessage);
		}
	}
	public void updateSilverPrice(double silverPrice) throws InvalidSilverPriceException {		//Method to update Silver price
		if(isValidGoldSilver(silverPrice)){
			daoObject.updateSilverPrice(silverPrice);
		}
		else{
			throw new InvalidSilverPriceException(ErrorMessages.invalidPriceMessage);
		}
	}
	public void updateMF(BankMutualFund mutualFund) throws InvalidMFException{					//Method to update Mutual Fund plans
		if(isValidMutualFund(mutualFund)){
			daoObject.updateMF(mutualFund);
		}
		else{
			throw new InvalidMFException(ErrorMessages.invalidMFMessage);
		}
		
	}
	@Override
	public boolean validateBank(String userId, String password) throws InvalidDetailsException {
		
		if(daoObject.viewDetails(userId)!=null){
			if (userId.equals(daoObject.viewDetails(userId).getUserId())) {

				String correctPassword = daoObject.viewDetails(userId).getPassword();
				if (password.equals(correctPassword)) {
					return true;
				}else {
					throw new InvalidDetailsException("Invalid Password");
				}
			}
			}
			else{
				throw new InvalidDetailsException("Invalid Username");
			}
			return false;
		
		
	}
}