package com.cg.ibs.investment.exception;

public interface ErrorMessages extends IBSException {
	public static final String invalidUnitsMessage =  "Please eneter valid weight ";
	public static final String invalidAmountMessage = "Please eneter valid amount ";
	public static final String invalidDetailsMessage = "Please enter valid details";
	public static final String insuffBalanceMessage = "Your account has Insufficient balance";
	public static final String invalidPriceMessage = "Please enter valid price";
	public static final String invalidMFMessage = "Please select a valid plan";
	public static final String invalidAccountMessage ="Account not available";
	public static final String invalidPassMessage ="Invalid Password";
	public static final String invalidUsernameMessage ="Invalid Username or Password";
}
