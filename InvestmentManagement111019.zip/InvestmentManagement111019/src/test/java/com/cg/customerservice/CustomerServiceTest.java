package com.cg.customerservice;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.ClientService;
import com.cg.ibs.investment.service.ClientServiceImpl;
public class CustomerServiceTest {
	
	@Test
	public void viewInvestments() throws IBSException {
		ClientService clientService=new ClientServiceImpl();
		assertNotNull(clientService.viewInvestments("a"));
	}
	@Test
	public void viewInvestmentsCheckNull() throws IBSException {
		ClientService clientService=new ClientServiceImpl();
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.viewInvestments("null") ; });
	}
	@Test
	public void buyGold()  {
		ClientService clientService=new ClientServiceImpl();
		try {
		clientService.buyGold(10, "a");
		assertEquals(60000,clientService.viewInvestments("a").getBalance());
		assertEquals(230,clientService.viewInvestments("a").getGoldunits());}
		catch(IBSException e) {
			System.out.println(e.getMessage());
		}
	}
	@Test
	public void checkSufficientBalance(){
		ClientService clientService=new ClientServiceImpl();
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.buyGold(100, "a"); });}
		
	@Test
	public void checkNegativeInputOfGoldUniits() {
		ClientService clientService=new ClientServiceImpl();
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.buyGold(-100, "a") ; });
		
	}
	
	public void checkSellGold() {
		ClientService clientService=new ClientServiceImpl();
		try {
			clientService.sellGold(10, "a");
			assertEquals(101000,clientService.viewInvestments("a").getBalance());
			assertEquals(210,clientService.viewInvestments("a").getGoldunits());}
			catch(IBSException e) {
				System.out.println(e.getMessage());
			}
		
	}

	public void checkSufficientGoldUnits(){
		ClientService clientService=new ClientServiceImpl();
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.sellGold(100, "a"); });}
	@Test
	public void checkNegativeInputOfGoldUniitsSelling() {
		ClientService clientService=new ClientServiceImpl();
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.sellGold(-100, "a") ; });
		
	}
	

	
   
		
	
	
	
	
	
}
