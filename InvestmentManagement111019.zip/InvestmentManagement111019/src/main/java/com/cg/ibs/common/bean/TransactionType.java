package com.cg.ibs.common.bean;

public enum TransactionType {
	CREDIT, DEBIT,GOLD_DEBIT,GOLD_CREDIT,SILVER_DEBIT,SILVER_CREDIT
}
