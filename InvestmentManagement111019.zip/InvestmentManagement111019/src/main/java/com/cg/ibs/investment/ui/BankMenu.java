package com.cg.ibs.investment.ui;

public enum BankMenu {
	UPDATE_GOLD_PRICE, UPDATE_SILVER_PRICE, ADD_MUTUALFUND_PLAN, QUIT

}
