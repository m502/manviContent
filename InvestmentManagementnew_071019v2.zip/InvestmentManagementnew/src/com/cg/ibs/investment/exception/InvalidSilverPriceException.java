package com.cg.ibs.investment.exception;

public class InvalidSilverPriceException extends Exception implements IBSException {


	private static final long serialVersionUID = 1L;

	public InvalidSilverPriceException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidSilverPriceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidSilverPriceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidSilverPriceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidSilverPriceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
