package com.cg.ibs.investment.ui;

public enum BankMenu {
	updateGoldPrice,updateSilverPrice,updateMFplans,Quit

}
