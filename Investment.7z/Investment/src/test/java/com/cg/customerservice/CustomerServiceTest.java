package com.cg.customerservice;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.dao.BankMutualFundDao;
import com.cg.ibs.investment.dao.BankMutualFundDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.dao.GoldPriceDao;
import com.cg.ibs.investment.dao.GoldPriceDaoImpl;
import com.cg.ibs.investment.dao.InvestmentDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.dao.SilverPriceDao;
import com.cg.ibs.investment.dao.SilverPriceDaoImpl;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;

class CustomerServiceImplTest {

	CustomerService customertService;
	BankService bankService;
	InvestmentBean investmentBean;
	CustomerDao clientDao;

	@BeforeEach
	void doit() {
		customertService = new CustomerServiceImpl();
		bankService = new BankServiceImpl();
		// investmentBean = new InvestmentBean("user1", "pqr888");

	}

	@Test
	@DisplayName("View Gold Price")
	void testViewGoldPrice() {
		GoldPriceDao dao = new GoldPriceDaoImpl();
		assertNotNull(dao.viewGoldPrice());
	}

	@Test
	@DisplayName("View Silver Price")
	void testViewSilverPrice() {
		SilverPriceDao dao = new SilverPriceDaoImpl();
		assertNotNull(dao.viewSilverPrice());
	}

	@Test
	@DisplayName("View MF Plans")
	void testViewtMF() {
		BankMutualFundDao dao = new BankMutualFundDaoImpl();
		assertNotNull(dao.getAllBankMutualFunds());
	}

	@Test
	@DisplayName("View My Investments")
	void testViewInv() {
		CustomerDao cs = new CustomerDaoImpl();
		InvestmentDao invdao = new InvestmentDaoImpl();
		assertNotNull(cs.getUciByUserId("user1"));
		assertNotNull(invdao.getInvestmentByUci(new BigInteger("1234123412341234")));
	}

	@Nested
	@DisplayName("Testing Buy Gold Method")
	class BuyGold {
		CustomerService customerService = new CustomerServiceImpl();
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId("user1");
		InvestmentDao invdao = new InvestmentDaoImpl();
		InvestmentBean inv = invdao.getInvestmentByUci(uci);

		@Test
		@DisplayName("Buy Gold Balance Positive")
		void testGoldBalanceUnits() {

			try {
				Double initialgu = inv.getGoldunits();
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.buyGold(1, "user1");
				Double finalgu = inv.getGoldunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = finalgu - initialgu;
				BigDecimal diffb = initialb.subtract(finalb);
				Double gp = customerService.viewGoldPrice();
				assertAll(() -> assertEquals(diff, 1), () -> assertEquals(diffb, new BigDecimal(1 * gp)));

			} catch (IBSException e) {
				assertNotNull(e);
			}
		}

		@Test
		@DisplayName("Buy Gold Balance Negative")
		void testGoldBalanceUnits2() {
			try {
				BigDecimal initialb = inv.getAccount().getBalance();
				Double initialgu = inv.getGoldunits();
				customerService.buyGold(1, "user1");
				Double finalgu = inv.getGoldunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = finalgu - initialgu;
				BigDecimal diffb = initialb.subtract(finalb);
				assertAll(() -> assertNotEquals(diff, -10), () -> assertNotEquals(diffb, new BigDecimal(200)));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Disabled
		@Test
		@DisplayName("Buy Gold Exceptions")
		void testGoldBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.buyGold(10000, "user1");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.buyGold(-10, "user1");
			}));

		}

	}

	@Nested
	@DisplayName("Testing Buy Silver Method")
	class BuySilver {
		CustomerService customerService = new CustomerServiceImpl();
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId("user1");
		InvestmentDao invdao = new InvestmentDaoImpl();
		InvestmentBean inv = invdao.getInvestmentByUci(uci);

		@Test
		@DisplayName("Buy Silver Balance Positive")
		void testSilverBalanceUnits() {

			try {
				Double initialsu = inv.getSilverunits();
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.buySilver(10, "user1");
				Double finalsu = inv.getSilverunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = finalsu - initialsu;
				BigDecimal diffb = initialb.subtract(finalb);
				Double sp = customerService.viewSilverPrice();
				assertAll(() -> assertEquals(diff, 10), () -> assertEquals(diffb, new BigDecimal(10 * sp)));

			} catch (IBSException e) {
				assertNotNull(e);
			}
		}

		@Test
		@DisplayName("Buy Silver Balance Negative")
		void testSilverBalanceUnits2() {
			try {
				BigDecimal initialb = inv.getAccount().getBalance();
				Double initialsu = inv.getSilverunits();
				customerService.buySilver(100, "user1");
				Double finalsu = inv.getSilverunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = finalsu - initialsu;
				BigDecimal diffb = initialb.subtract(finalb);
				assertAll(() -> assertNotEquals(diff, -10), () -> assertNotEquals(diffb, new BigDecimal(200)));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Buy Silver Exceptions")
		void testSilverBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.buyGold(10000, "user1");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.buyGold(-10, "user1");
			}));

		}

	}

	@Nested
	@DisplayName("Testing Sell Gold Method")
	class SellGold {
		CustomerService customerService = new CustomerServiceImpl();
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId("user1");
		InvestmentDao invdao = new InvestmentDaoImpl();
		InvestmentBean inv = invdao.getInvestmentByUci(uci);

		@Test
		@DisplayName("Sell Gold Balance Positive")
		void testGoldBalanceUnits() {
			try {
				Double initialgu = inv.getGoldunits();
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.sellGold(5, "user1");
				Double finalgu = inv.getGoldunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = initialgu - finalgu;
				BigDecimal diffb = finalb.subtract(initialb);
				Double gp = customerService.viewGoldPrice();
				assertAll(() -> assertEquals(diff, 5), () -> assertEquals(diffb, new BigDecimal(5 * gp)));

			} catch (IBSException e) {
				assertNotNull(e);
			}
		}

		@Test
		@DisplayName("Sell Gold Balance Negative")
		void testGoldBalanceUnits2() {
			try {
				Double initialgu = inv.getGoldunits();
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.sellGold(5, "user1");
				Double finalgu = inv.getGoldunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = initialgu - finalgu;
				BigDecimal diffb = finalb.subtract(initialb);
				Double gp = customerService.viewGoldPrice();
				assertAll(() -> assertNotEquals(diff, 50), () -> assertNotEquals(diffb, new BigDecimal(-2 * gp)));

			} catch (IBSException e) {
				assertNotNull(e);
			}
		}

		@Test
		@DisplayName("Sell Gold Exceptions")
		void testGoldBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.sellGold(10000, "user1");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.sellGold(-10, "user1");
			}));
		}
	}

	@Nested
	@DisplayName("Testing Sdell Silver Method")
	class SellSilver {
		CustomerService customerService = new CustomerServiceImpl();
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId("user1");
		InvestmentDao invdao = new InvestmentDaoImpl();
		InvestmentBean inv = invdao.getInvestmentByUci(uci);

		@Test
		@DisplayName("Sell Silver Balance Positive")
		void testSilverBalanceUnits() {
			try {
				Double initialsu = inv.getSilverunits();
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.sellSilver(20, "user1");
				Double finalsu = inv.getSilverunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = initialsu - finalsu;
				BigDecimal diffb = finalb.subtract(initialb);
				Double sp = customerService.viewSilverPrice();
				assertAll(() -> assertEquals(diff, 20), () -> assertEquals(diffb, new BigDecimal(20 * sp)));

			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Sell Silver Balance Negative")
		void testSilverdBalanceUnits2() {
			try {
				Double initialsu = inv.getSilverunits();
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.sellSilver(20, "user1");
				Double finalsu = inv.getSilverunits();
				BigDecimal finalb = inv.getAccount().getBalance();
				Double diff = initialsu - finalsu;
				BigDecimal diffb = finalb.subtract(initialb);
				Double sp = customerService.viewSilverPrice();
				assertAll(() -> assertNotEquals(diff, 200), () -> assertNotEquals(diffb, new BigDecimal(-20 * sp)));

			} catch (IBSException e) {
				assertNotNull(e);
			}
		}

		@Test
		@DisplayName("Sell Silver Exceptions")
		void testSilverBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.sellSilver(100000, "user1");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.sellSilver(-10, "user1");
			}));
		}
	}

	@Nested
	@DisplayName("Testing Invest MF Method")
	class InvestMF {
		CustomerService customerService = new CustomerServiceImpl();
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId("user1");
		InvestmentDao invdao = new InvestmentDaoImpl();
		InvestmentBean inv = invdao.getInvestmentByUci(uci);

		@Test
		@DisplayName("Invest MF Positive")
		void testInvestMF() {

			try {
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.investMF(5000, "user1", 10001);
				BigDecimal finalb = inv.getAccount().getBalance();
				BigDecimal diffb = initialb.subtract(finalb);
				assertAll(() -> assertEquals(diffb, new BigDecimal(5000)), () -> assertNotNull(inv.getFunds()));

			} catch (IBSException e) {
				assertNotNull(e);
			}
		}

		@Test
		@DisplayName("Invest MF Negative")
		void testInvestMF2() {
			try {
				BigDecimal initialb = inv.getAccount().getBalance();
				customerService.investMF(5000, "user1", 10001);
				BigDecimal finalb = inv.getAccount().getBalance();
				BigDecimal diffb = initialb.subtract(finalb);
				assertNotEquals(diffb, new BigDecimal(1000));

			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Invest MF Exceptions")
		void testInvestMF3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.investMF(-1000, "user1", 10001);
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.investMF(10000, "user1", 10009);
			})

			);
		}
	}

}
