package com.cg.ibs.investment.ui;

public enum BankMenu {
	GOLD, SILVER, MUTUALFUND_PLAN, QUIT

}
