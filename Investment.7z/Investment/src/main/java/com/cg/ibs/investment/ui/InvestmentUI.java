package com.cg.ibs.investment.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;
@Component
public class InvestmentUI {
	static Scanner sc= new Scanner(System.in);
	static int status = 3;
	static Logger log = Logger.getLogger(InvestmentUI.class.getName());

	// Declaring objects of Client Service and Bank Service

	CustomerService service = new CustomerServiceImpl();
	
	BankService bankservice = new BankServiceImpl();
	
	BankUI bankUi = new BankUI();
	
	CustomerUi custUi= new CustomerUi();

	// Method to start the program
	public void doIt() {
		
		while (status == 3) {
			System.out.println("	Press 1 for customer and 2 for bank representative");
			System.out.println("----------------------------------------------------------");
			boolean check = true;
			String temp = sc.next();
			while (check) {

				if (temp.matches("[0-9]")) {
					status = Integer.parseInt(temp);
					check = false;
				} else {
					System.out.println("Please Re-enter");
					temp = sc.next();
				}
			}

			Menu choice = null;
			BankMenu option = null;

			// Options for the Customer
			if (status == 1) {
				System.out.println("Enter the userId");
				String userId = sc.next();
				System.out.println("Enter the password");
				String password = sc.next();
				boolean check1 = true;

				while (check1) {
					try {
						if (service.validateCustomer(userId, password)) {
							while (choice != Menu.QUIT) {
								System.out.println("--------------------");
								System.out.println("Choice");
								System.out.println("--------------------");
								for (Menu menu : Menu.values()) {
									System.out.println(menu.ordinal() + 1 + "\t" + menu.toString().replace("_", " "));
								}
								boolean check2 = true;
								int ordinal = 0;
								String temp1 = sc.next();
								while (check2) {

									if (temp1.matches("[0-9]+")) {
										ordinal = Integer.parseInt(temp1);
										check2 = false;
									} else {
										System.out.println("Please Re-enter");
										temp1 = sc.next();
									}
								}

								// int ordinal = sc.nextInt();
								if (ordinal >= 1 && ordinal <= Menu.values().length) {
									choice = Menu.values()[ordinal - 1];

									switch (choice) {
									case VIEW_MY_INVESTMENT:
										custUi.viewMyInvestments(userId);

										break;
									case VIEW_MY_TRANSACTIONS:
										custUi.viewMyTransactions(userId);
										break;
									case VIEW_GOLD_PRICE:										
										System.out.println("Gold price is Rs. " + service.viewGoldPrice());										
										break;
									case VIEW_SILVER_PRICE:
										System.out.println("Silver price is Rs. " + service.viewSilverPrice());
										break;
									case VIEW_MF_PLANS:
										ViewMFPlans choice23=null;
										while (choice23 != ViewMFPlans.GO_BACK) {
											System.out.println("--------------------");
											System.out.println("Choice");
											System.out.println("--------------------");
											for (ViewMFPlans menu23 : ViewMFPlans.values()) {
												System.out.println(menu23.ordinal() + 1 + "\t" + menu23.toString().replace("_", " "));
											}
											boolean check23 = true;
											int ordinal23 = 0;
											String temp23 = sc.next();
											while (check23) {

												if (temp23.matches("[0-9]+")) {
													ordinal23 = Integer.parseInt(temp23);
													check23 = false;
												} else {
													System.out.println("Please Re-enter");
													temp23 = sc.next();
												}
											}
											if (ordinal23 >= 1 && ordinal23 <= ViewMFPlans.values().length) {
												choice23 = ViewMFPlans.values()[ordinal23 - 1];
												switch (choice23) {
												case SIP:
												custUi.viewMFPlans("SIP");
												break;
												case DIRECT:
												custUi.viewMFPlans("DIRECT");	
												break;												
												case SIP_AND_DIRECT:
												custUi.viewMFPlans("SIP_AND_DIRECT");
												break;
												case GO_BACK:
													check1=false;
												break;
												
												}
												
												
											}}
										
										
										break;
									case BUY_GOLD:
										custUi.buyGold(userId);
										break;
									case SELL_GOLD:
										custUi.sellGold(userId);
										break;
									case BUY_SILVER:
										custUi.buySilver(userId);
										break;
									case SELL_SILVER:
										custUi.sellSilver(userId);
										break;
									case INVEST_MF_PLAN:
										
										ViewMFPlans choice24=null;
										while (choice24 != ViewMFPlans.GO_BACK) {
											System.out.println("--------------------");
											System.out.println("Choice");
											System.out.println("--------------------");
											for (ViewMFPlans menu24 : ViewMFPlans.values()) {
												if(menu24.ordinal()!=2&& menu24.ordinal()!=3) {
												System.out.println(menu24.ordinal() + 1 + "\t" + menu24.toString().replace("_", " "));
											}
												else if(menu24.ordinal()==3) {
													System.out.println(menu24.ordinal() + "\t" + menu24.toString().replace("_", " "));
													}
												}
											boolean check24 = true;
											int ordinal24 = 0;
											String temp24 = sc.next();
											while (check24) {

												if (temp24.matches("[0-9]+")) {
													ordinal24 = Integer.parseInt(temp24);
													check24 = false;
												} else {
													System.out.println("Please Re-enter");
													temp24 = sc.next();
												}
											}
											if (ordinal24 >= 1 && ordinal24 <= ViewMFPlans.values().length) {
												if(ordinal24==3) {
													choice24 = ViewMFPlans.values()[3];	
												}else {
													choice24 = ViewMFPlans.values()[ordinal24 - 1];
												}
												
												switch (choice24) {
												case SIP:
												custUi.investMFPlan(userId, "SIP");
												break;
												case DIRECT:
												custUi.investMFPlan(userId, "DIRECT");	
												break;												
												case GO_BACK:
													check1=false;
												break;
												
												}
												
												
											}}
										
										break;
									case WITHDRAW_MF_PLAN:
										custUi.withdrawMFPlan(userId);
										break;									
									case LINK_NEW_ACCOUNT:
										custUi.linkAccount(userId);
										break;
									case QUIT:

										System.out.println("You are successfully logged out");
										break;

									}

								} else {
									System.out.println("Invalid Option");

								}

							}
							check1 = false;

						} else {
							System.out.println("Invalid Username Or Password");
							System.out.println("Enter the userId");
							userId = sc.next();
							System.out.println("Enter the password");
							password = sc.next();
						}
					} catch (IBSException e) {
						log.error(e);
						System.out.println(e.getMessage());
					}
				}
				System.out.println("Press 3 to continue, any other number to EXIT");
				boolean check10 = true;
				String temp10 = sc.next();
				while (check10) {

					if (temp10.matches("[0-9]{1,20}")) {
						status = Integer.parseInt(temp10);
						check10 = false;
					} else {
						System.out.println("Please Re-enter");
						temp10 = sc.next();
					}
				}

			}
			// Options for the Bank Representative
			else if (status == 2) {
				System.out.println("Enter the userId");
				String userId = sc.next();
				System.out.println("Enter the password");
				String password = sc.next();
				boolean check1 = true;

				while (check1) {
					
					try {
						
						if (bankservice.validateBank(userId, password)) {
							while (option != BankMenu.QUIT) {
								System.out.println("--------------------");
								System.out.println("Choice");
								System.out.println("--------------------");
								for (BankMenu menu : BankMenu.values()) {
									System.out.println(menu.ordinal() + 1 + "\t" + menu.toString().replace("_", " "));
								}
								boolean check2 = true;
								int ordinal = 0;
								String temp1 = sc.next();
								while (check2) {

									if (temp1.matches("[0-9]+")) {
										ordinal = Integer.parseInt(temp1);
										check2 = false;
									} else {
										System.out.println("Please Re-enter");
										temp1 = sc.next();
									}
								}

								// int ordinal = sc.nextInt();
								if (ordinal >= 1 && ordinal <= BankMenu.values().length) {
									option = BankMenu.values()[ordinal - 1];

									switch (option) {
									case GOLD:
										
										
										Functions choice25=null;
										while (choice25 != Functions.GO_BACK) {
											System.out.println("--------------------");
											System.out.println("Choice");
											System.out.println("--------------------");
											for ( Functions menu25 :  Functions.values()) {
												
													System.out.println(menu25.ordinal() +1+ "\t" + menu25.toString().replace("_", " "));
													
												}
											boolean check25 = true;
											int ordinal25 = 0;
											String temp25 = sc.next();
											while (check25) {

												if (temp25.matches("[0-9]+")) {
													ordinal25 = Integer.parseInt(temp25);
													check25 = false;
												} else {
													System.out.println("Please Re-enter");
													temp25 = sc.next();
												}
											}
											if (ordinal25 >= 1 && ordinal25 <= Functions.values().length) {
												
													choice25 = Functions.values()[ordinal25 - 1];
												}
												
												switch (choice25) {
												case VIEW:
													System.out.println("Gold price is Rs. " + service.viewGoldPrice());		
												
												break;
												case UPDATE:
													log.info("logggg");
													bankUi.updateGoldPrice();
													
												break;												
												case GO_BACK:
													check1=false;
												break;
												
												}
												
												
											}
										
										break;
									case SILVER:
										Functions choice26=null;
										while (choice26 != Functions.GO_BACK) {
											System.out.println("--------------------");
											System.out.println("Choice");
											System.out.println("--------------------");
											for ( Functions menu26 :  Functions.values()) {
												
													System.out.println(menu26.ordinal() +1+ "\t" + menu26.toString().replace("_", " "));
													
												}
											boolean check26 = true;
											int ordinal26 = 0;
											String temp26 = sc.next();
											while (check26) {

												if (temp26.matches("[0-9]+")) {
													ordinal26 = Integer.parseInt(temp26);
													check26 = false;
												} else {
													System.out.println("Please Re-enter");
													temp26 = sc.next();
												}
											}
											if (ordinal26 >= 1 && ordinal26 <= Functions.values().length) {
												
													choice26 = Functions.values()[ordinal26 - 1];
												}
												
												switch (choice26) {
												case VIEW:
													System.out.println("Silver price is Rs. " + service.viewSilverPrice());		
												
												break;
												case UPDATE:
													bankUi.updateSiverPrice();
													
												break;												
												case GO_BACK:
													check1=false;
												break;
												
												}
												
												
											}
										break;
									case MUTUALFUND_PLAN:
										
										BankMf choice27=null;
										while (choice27 != BankMf.GO_BACK) {
											System.out.println("--------------------");
											System.out.println("Choice");
											System.out.println("--------------------");
											for ( BankMf menu27 :  BankMf.values()) {
												
													System.out.println(menu27.ordinal() +1+ "\t" + menu27.toString().replace("_", " "));
													
												}
											boolean check27 = true;
											int ordinal27 = 0;
											String temp27 = sc.next();
											while (check27) {

												if (temp27.matches("[0-9]+")) {
													ordinal27 = Integer.parseInt(temp27);
													check27 = false;
												} else {
													System.out.println("Please Re-enter");
													temp27 = sc.next();
												}
											}
											if (ordinal27 >= 1 && ordinal27 <= BankMf.values().length) {
												
													choice27 = BankMf.values()[ordinal27 - 1];
												}
												
												switch (choice27) {
												case ADD:
													bankUi.addMFPlans();	
												
												break;
												case UPDATE:
													bankUi.updateMf();
													
												break;
												case REMOVE:
													
													break;
												case GO_BACK:
													check1=false;
												break;
												
												}
												
												
											}
										break;
									case QUIT:
										System.out.println("You are successfully logged out");

										break;

									}

								} else {
									System.out.println("Invalid Option");

								}

							}
							check1 = false;

						} else {
							System.out.println("Invalid Username Or Password");
							System.out.println("Enter the userId");
							userId = sc.next();
							System.out.println("Enter the password");
							password = sc.next();
						}
					} catch (IBSException e) {
						log.error(e);
						System.out.println(e.getMessage());
					}
				}
				System.out.println("Press 3 to continue, any other number to EXIT");
				boolean check11 = true;
				String temp11 = sc.next();
				while (check11) {

					if (temp11.matches("[0-9]{1,22}")) {
						status = Integer.parseInt(temp11);
						check11 = false;
					} else {
						System.out.println("Please Re-enter");
						temp11 = sc.next();
					}
				}
			} else {
				System.out.println("Please enter valid choice");
				System.out.println("Press 3 to continue");
				boolean check12 = true;
				String temp12 = sc.next();
				while (check12) {

					if (temp12.matches("[0-9]{1,23}")) {
						status = Integer.parseInt(temp12);
						check12 = false;
					} else {
						System.out.println("Please Re-enter");
						temp12 = sc.next();
					}
				}
			}
		}

	}

	

	

	


	// Main Method
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("investment.xml");
		InvestmentUI investmentUI=context.getBean("investmentUI", InvestmentUI.class);
		sc = new Scanner(System.in);
		//InvestmentUI investmentUI = new InvestmentUI();
		investmentUI.doIt();
		System.out.println("The program has ended");
		sc.close();

	}
}