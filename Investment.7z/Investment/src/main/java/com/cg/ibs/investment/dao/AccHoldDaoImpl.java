package com.cg.ibs.investment.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.util.JPAUtil;
@Repository
public class AccHoldDaoImpl implements AccHoldDao {
	private EntityManager entityManager;

	public AccHoldDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	@Override
	public AccountHoldingBean addAccountHold(AccountHoldingBean accHold) {		
		entityManager.persist(accHold);
		return accHold;
	}

	@Override
	public AccountHoldingBean updateAccountHold(AccountHoldingBean accHold) {
		
		return null;
	}

	@Override
	public AccountHoldingBean getAccountByAccNo(Long aHId) {
		
		return null;
	}

	@Override
	public List<AccountHoldingBean> getAllAccounts() {
		
		return null;
	}

	@Override
	public boolean removeAccountHold(Long aHId) {
		// TODO Auto-generated method stub
		return false;
	}

}
