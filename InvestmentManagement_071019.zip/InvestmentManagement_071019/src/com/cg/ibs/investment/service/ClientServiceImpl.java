package com.cg.ibs.investment.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.TreeSet;

import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.dao.ClientDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.exception.ErrorMessages;
import com.cg.ibs.investment.exception.InsuffBalanceException;
import com.cg.ibs.investment.exception.InvalidAmountException;
import com.cg.ibs.investment.exception.InvalidDetailsException;
import com.cg.ibs.investment.exception.InvalidUnitsException;


public class ClientServiceImpl implements ClientService {
	static long count=0; 
	ClientDao clientdao = new InvestmentDaoImpl();

	@Override
	public HashMap<Integer, BankMutualFund> viewMFPlans() { 		//Method to view Mutual fund plans
		return (clientdao.viewMF()); 								//Retrieves the Mutual fund plans from Dao layer & displays it to customer
	}

	@Override
	public double viewGoldPrice() { 								//Method to view Gold price
		return (clientdao.viewGoldPrice());							//Retrieves the Mutual fund plans from Dao layer & displays it to customer

	}

	@Override
	public double viewSilverPrice() { 								//Method to view silver price
		return (clientdao.viewSilverPrice());						//Retrieves the Mutual fund plans from Dao layer & displays it to customer

	}

	@Override
	public void buyGold(double gunits, String userId) throws InvalidUnitsException, InsuffBalanceException, InvalidDetailsException,InputMismatchException {
		
		if (gunits > 0 ) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId); 
			if (investmentBean.getBalance() >= gunits * clientdao.viewGoldPrice()) {
				LocalDate dt=LocalDate.now();
				investmentBean.setGoldunits(investmentBean.getGoldunits() + gunits);							//Updates the Gold bought by customer
				investmentBean.setBalance(investmentBean.getBalance() - gunits * clientdao.viewGoldPrice());	//updates the Balance of customer after a transaction
				BigInteger TransactionId=new BigInteger("1001001000031").add(BigInteger.valueOf(count));
				TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.DEBIT, dt , BigDecimal.valueOf(gunits*clientdao.viewGoldPrice()));
				investmentBean.getTransactionList().add(trxn1);
				investmentBean.setTransactionList(investmentBean.getTransactionList());
			count ++;

			} else {
				
				throw new InsuffBalanceException(ErrorMessages.insuffBalanceMessage);		//Exception will be thrown if customer has Insufficient balance
			}

		} else {
			throw new InvalidUnitsException(ErrorMessages.invalidUnitsMessage);				//Exception will be thrown if customer enters invalid weight 
			
		}
		}

	@Override
	public void sellGold(double gunits, String userId) throws InvalidUnitsException, InvalidDetailsException, InsuffBalanceException {
		InvestmentBean investmentBean = clientdao.viewInvestments(userId);
		if (gunits > 0) {
			if ( gunits < investmentBean.getGoldunits()) {
				investmentBean.setGoldunits(investmentBean.getGoldunits() - gunits);							//Updates the Gold sold by customer
				investmentBean.setBalance(investmentBean.getBalance() + gunits * clientdao.viewGoldPrice());	//updates the Balance of customer after a transaction
				LocalDate dt=LocalDate.now();
				investmentBean.setGoldunits(investmentBean.getGoldunits() + gunits);
				investmentBean.setBalance(investmentBean.getBalance() - gunits * clientdao.viewGoldPrice());
				BigInteger TransactionId=new BigInteger("100100100003").add(BigInteger.valueOf(count));
				TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.CREDIT, dt , BigDecimal.valueOf(gunits*clientdao.viewGoldPrice()));
				investmentBean.getTransactionList().add(trxn1);
				investmentBean.setTransactionList(investmentBean.getTransactionList());
			count ++;
			}else {
				throw new InsuffBalanceException(ErrorMessages.insuffBalanceMessage); 		//Exception will be thrown if customer has insufficient gold
			}

			

		} else {
			throw new InvalidUnitsException(ErrorMessages.invalidUnitsMessage);			//Exception will be thrown if customer enters invalid weight 
		}

	}

	@Override
	public void buySilver(double sunits, String userId)  throws InsuffBalanceException, InvalidUnitsException, InvalidDetailsException {

		if (sunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			if (investmentBean.getBalance() >= sunits * clientdao.viewSilverPrice()) {

				investmentBean.setSilverunits(investmentBean.getSilverunits() + sunits);						//Updates the Silver bought by customer
				investmentBean.setBalance(investmentBean.getBalance() - sunits * clientdao.viewSilverPrice());	//updates the Balance of customer after a transaction
				LocalDate dt=LocalDate.now();
				investmentBean.setGoldunits(investmentBean.getGoldunits() + sunits);
				investmentBean.setBalance(investmentBean.getBalance() - sunits * clientdao.viewGoldPrice());
				BigInteger TransactionId=new BigInteger("10010010002").add(BigInteger.valueOf(count));
				TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.DEBIT, dt , BigDecimal.valueOf(sunits * clientdao.viewSilverPrice()));
				investmentBean.getTransactionList().add(trxn1);
				investmentBean.setTransactionList(investmentBean.getTransactionList());
			count ++;


			} else {
				throw new InsuffBalanceException(ErrorMessages.insuffBalanceMessage);	//
			}

		} else {
			throw new InvalidUnitsException(ErrorMessages.invalidUnitsMessage);			//Exception will be thrown if customer enters invalid weight 
		}

	}

	@Override
	public void sellSilver(double sunits, String userId)  throws InvalidUnitsException, InvalidDetailsException, InsuffBalanceException {
		InvestmentBean investmentBean = clientdao.viewInvestments(userId);
		if (sunits > 0) {
			if (sunits < investmentBean.getSilverunits()) {
				investmentBean.setSilverunits(investmentBean.getSilverunits() - sunits);						//Updates the Silver bought by customer
				investmentBean.setBalance(investmentBean.getBalance() + sunits * clientdao.viewSilverPrice());	//updates the Balance of customer after a transaction
				LocalDate dt=LocalDate.now();
				investmentBean.setGoldunits(investmentBean.getGoldunits() + sunits);
				investmentBean.setBalance(investmentBean.getBalance() - sunits * clientdao.viewGoldPrice());
				BigInteger TransactionId=new BigInteger("100100100003").add(BigInteger.valueOf(count));
				TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.CREDIT, dt , BigDecimal.valueOf(sunits*clientdao.viewGoldPrice()));
				investmentBean.getTransactionList().add(trxn1);
				investmentBean.setTransactionList(investmentBean.getTransactionList());
			count ++;
			}else {
				throw new InsuffBalanceException(ErrorMessages.insuffBalanceMessage);
			}

		} else {
			throw new InvalidUnitsException(ErrorMessages.invalidUnitsMessage);
		}
	}

	@Override
	public void investMF(double mfAmount, String userId, Integer mfId)  throws InsuffBalanceException, InvalidAmountException, InvalidDetailsException {
		if (mfAmount > 0) {
			if (clientdao.viewMF().containsKey(mfId)) {
				InvestmentBean investmentBean = null;
			
					investmentBean = clientdao.viewInvestments(userId);
				
				double nav = clientdao.viewMF().get(mfId).getNav();
                 
				if (investmentBean.getBalance() >= mfAmount) {
					MutualFund mutualFund=new MutualFund();
					mutualFund.setmfid(mfId);
					mutualFund.setTitle(clientdao.viewMF().get(mfId).getTitle());
					mutualFund.setNav(clientdao.viewMF().get(mfId).getNav());
					LocalDate dt=LocalDate.now();			
			      double mfunits=(mfAmount / nav);
			      mutualFund.setMfUnits(mfunits);
			      mutualFund.setOpeningDate(dt);
			      mutualFund.setStatus(true);
			      
					investmentBean.getFunds().add(mutualFund);
					investmentBean.setFunds(investmentBean.getFunds());						
						
						investmentBean.setBalance(investmentBean.getBalance() - mfAmount);
						BigInteger TransactionId=new BigInteger("100100100").add(BigInteger.valueOf(count));
						TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.DEBIT, dt , BigDecimal.valueOf(mfAmount));
						investmentBean.getTransactionList().add(trxn1);
						investmentBean.setTransactionList(investmentBean.getTransactionList());
					count ++;
					

				} else {
					throw new InsuffBalanceException(ErrorMessages.insuffBalanceMessage);
				}
			}else{
				throw new InvalidDetailsException(ErrorMessages.invalidDetailsMessage);
			}
		} else {
			throw new InvalidAmountException(ErrorMessages.invalidAmountMessage);
		}
	}

	@Override
	public void withdrawMF( String userId, MutualFund mutualFund) throws InvalidDetailsException   {
		
		if(clientdao.viewInvestments(userId)!=null){
			InvestmentBean investmentBean = clientdao.viewInvestments(userId);
			investmentBean.setBalance(investmentBean.getBalance() + mutualFund.getMfAmount());
			
				investmentBean.getFunds().remove(mutualFund);
				LocalDate dt=LocalDate.now();
			
				BigInteger TransactionId=new BigInteger("1001001001").add(BigInteger.valueOf(count));
				TransactionBean trxn1=new TransactionBean(TransactionId, TransactionType.CREDIT, dt , BigDecimal.valueOf(mutualFund.getMfAmount()));
				investmentBean.getTransactionList().add(trxn1);
				investmentBean.setTransactionList(investmentBean.getTransactionList());
			count ++;
			
		
		}else{
			throw new  InvalidDetailsException(ErrorMessages.invalidDetailsMessage);
		}
	}

	@Override
	public InvestmentBean viewInvestments(String userId) throws InvalidDetailsException{
		if(clientdao.viewInvestments(userId)!=null){
		return clientdao.viewInvestments(userId);}
		else{
			throw new InvalidDetailsException(ErrorMessages.invalidAccountMessage);
		}

	}

	@Override
	public boolean validateCustomer(String userId, String password) throws InvalidDetailsException {
		if(clientdao.viewInvestments(userId)!=null){
		if (userId.equals(clientdao.viewInvestments(userId).getUserId())) {

			String correctPassword = clientdao.viewInvestments(userId).getPassword();
			if (password.equals(correctPassword)) {
				return true;
			}else {
				throw new InvalidDetailsException(ErrorMessages.invalidPassMessage);
			}
		}
		}
		else{
			throw new InvalidDetailsException(ErrorMessages.invalidUsernameMessage);
		}
		return false;

	}

	@Override
	public TreeSet<TransactionBean> getTransactions(String userId) throws InvalidDetailsException {
		return clientdao.viewInvestments(userId).getTransactionList();
	}

}
